package com.lnt.mvc.dao;

import com.lnt.mvc.model.Registration;

public interface RegistrationDao {
public void save(Registration r);
}
