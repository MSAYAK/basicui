package com.nsp.model;

public class StateLogin {
	
	/**
	 * model class for state nodal officer login
	 */
	private String gstate_name;
	private String gstate_password;

	public String getGstate_name() {
		return gstate_name;
	}
	public void setGstate_name(String gstate_name) {
		this.gstate_name = gstate_name;
	}
	public String getGstate_password() {
		return gstate_password;
	}
	public void setGstate_password(String gstate_password) {
		this.gstate_password = gstate_password;
	}
}
