package com.nsp.model;

public class StudentLogin {
	
	/**
	 * model class for student login
	 */
	private long gs_aadhar;
	private String gs_password;
	public long getGs_aadhar() {
		return gs_aadhar;
	}
	public void setGs_aadhar(long gs_aadhar) {
		this.gs_aadhar = gs_aadhar;
	}
	public String getGs_password() {
		return gs_password;
	}
	public void setGs_password(String gs_password) {
		this.gs_password = gs_password;
	}
	
	
	
	
}
